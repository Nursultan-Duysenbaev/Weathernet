//
//  WeathernetApp.swift
//  Weathernet
//
//  Created by Nursultan Duysenbaev on 23/07/23.
//

import SwiftUI

@main
struct WeathernetApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
